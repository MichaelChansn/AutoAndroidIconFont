var express = require('express');
var router = express.Router();
var fs = require("fs");
var UUID = require('uuid');
var path = require('path');
// var unzip = require("unzip");
var async = require('async');
var rd = require('rd');
var webfontsGenerator = require('webfonts-generator');
var zipper = require("zip-local");
var rimraf = require("rimraf");
var mkdirp = require('mkdirp');

/* GET home page. */
router.get('/', function (req, res, next) {
    res.render('index', {title: 'Express'});


});

/* POST FILES */
router.post('/convert', function (req, res, next) {
    // 创建临时文件夹，用于存储档次请求的所有文件
    var tempDir = UUID.v1();
    var destFileDir = path.dirname(__dirname) + "/uploads/" + tempDir;
    var fileName = req.files[0].originalname;
    var topic = fileName.substring(0, fileName.indexOf('.zip'));
    var tempFilePath = req.files[0].path;
    if (!fsExistsSync(destFileDir)) {
        mkdirp.sync(destFileDir);
    }
    var destFile = destFileDir + '/' + req.files[0].originalname;
    if (fsExistsSync(destFile)) {
        fsDeleteSync(destFile);
    }

    // 复制文件
    fs.readFile(tempFilePath, function (err, data) {
        fs.writeFile(destFile, data, function (err) {
            if (err) {
                deleteTempFile(tempFilePath);
                console.log(err);
            } else {
                console.time('series');

                async.waterfall([
                    function(callback){
                        deleteTempFile(tempFilePath);
                        callback(null, 'one ok');
                    },
                    function(arg1, callback){
                        // arg1 now equals 'one'
                        unZipFile(destFile, topic, function (isOk, info) {
                            callback(null, 'two');
                        });
                    },
                    function(arg1, callback){
                        // arg1 now equals 'two'
                        var files = rd.readSync(destFileDir + '/' + topic);
                        callback(null, files);
                    },
                    function(arg1, callback){
                        // arg1 now equals 'files'
                        var svgs = filterSvgs(arg1);
                        callback(null, svgs);
                    },
                    function(arg1, callback){
                        // arg1 now equals 'svgs'
                        var ttfPath = destFileDir + '/iconfont/';
                        convert(arg1, ttfPath, function () {
                            callback(null, ttfPath);

                        });
                    },
                    function(arg1, callback){
                        // arg1 now equals 'ttfPath'
                        var ttfZipPath = zipCompress(arg1);
                        callback(null, ttfZipPath);
                    }
                ], function (err, result) {
                    // result now equals 'done'
                    console.log(result);
                    sendttfZip(result, res, function (error) {
                        console.error("send file ok");
                        rimraf.sync(destFileDir);
                        console.timeEnd('series');
                    });
                });



            }

        });
    });


});

function unZipFile(zipFilePath, topic, callback) {
    var destUnZipPath = path.dirname(zipFilePath) + '/' + topic + '/';

    if(!fsExistsSync(destUnZipPath)){
        mkdirp.sync(destUnZipPath);
    }
    zipper.sync.unzip(zipFilePath).save(destUnZipPath);
    deleteTempFile(zipFilePath);
    callback(true,'OK');

    // 一下是用unzip解压，异步，已经废弃
    // var extract = unzip.Extract({path: destUnZipPath});
    // extract.on('error', function(err) {
    //     console.log(" unzip error!!!!!!!!!!!!");
    //     console.log(err);
    //     //解压异常处理
    //     callback(false, err);
    // });
    // extract.on('close', function() {
    //     console.log("解压完成!!");
    //     //解压完成处理
    //     deleteTempFile(zipFilePath);
    //     callback(true,'OK');
    // });
    // fs.createReadStream(zipFilePath).pipe(extract);

}

function sendttfZip(ttfPath, res, callback) {
    res.download(ttfPath, 'iconfont.zip', function(err){
        callback(err);
    });
}


function deleteTempFile(tempFile) {
    rimraf.sync(tempFile);
}


function filterSvgs(allFiles) {
    var svgs = [];//这个就是你要的数组
    for (var i = 0; i < allFiles.length; i++) {
        if (allFiles[i].indexOf('.svg') >= 0) {
            svgs.push(allFiles[i])
        }
    }
    return svgs;
}

function convert(svgFiles, destDir,callback) {
    webfontsGenerator({
        files: svgFiles,
        dest: destDir,
        types:['ttf']
    }, function (error) {
        if (error) {
            console.log('Fail!', error);
            callback(false, error);
        } else {
            console.log('Done!');
            callback(true, error);

        }
    });
}

function zipCompress(ttfDir) {
    var ttfZipPath = path.dirname(ttfDir)+'/ttf.zip';
    zipper.sync.zip(ttfDir).compress().save(ttfZipPath);
    return ttfZipPath;
}

function fsExistsSync(path) {
    try {
        fs.accessSync(path, fs.F_OK);
    } catch (e) {
        return false;
    }
    return true;
}

function fsDeleteSync(path) {
    rimraf.sync(path);
    return true;
}

module.exports = router;
